# G.M. Automotive v11 – integrazione unica

## Unificato
- Un solo database SQLite per clienti, richieste, trasportatori e messaggi WhatsApp.
- Le richieste manuali e i messaggi WhatsApp compaiono nello stesso archivio.
- I messaggi WhatsApp in ingresso vengono salvati come richieste `DA_VERIFICARE`; ritiro e consegna restano da completare da parte dell'operatore quando il testo non è strutturato.
- Duplicati webhook evitati tramite ID messaggio WhatsApp.
- Firma `X-Hub-Signature-256` verificata.
- L'assegnazione resta manuale e disponibile solo a trasportatori approvati (endpoint API).

## Installazione
1. Installare Node.js 20 o superiore.
2. Estrarre il pacchetto sul server.
3. Eseguire `npm install`.
4. Copiare `.env.example` in `.env` e compilare le variabili.
5. Eseguire `npm start`.
6. Pubblicare su HTTPS e configurare in Meta il webhook `https://TUO-DOMINIO/webhooks/whatsapp`, con lo stesso `WHATSAPP_VERIFY_TOKEN`, sottoscrivendo `messages`.
7. Aprire il dominio e inserire la chiave amministratore.

## Stato reale e limiti
Questo è un pacchetto di codice pronto per installazione e test, NON un'app già pubblicata né un numero WhatsApp già collegato. La ricezione automatica parte solo dopo aver configurato l'app Meta, le credenziali e un endpoint HTTPS pubblico. Il pannello usa una chiave API come protezione provvisoria: prima della produzione va sostituita con login robusto, sessioni sicure, ruoli, rate limiting, audit log, backup e protezione CSRF. Mancano ancora gestione documenti/validità, GPS solo G.M., calcolo tariffa su percorso, verbali PDF e notifiche. Rispettare informativa e GDPR; definire tempi di conservazione.

## Versione 12 – distanza e tariffa
- Configurare `GOOGLE_MAPS_API_KEY` sul server e abilitare Google Routes API nel progetto Google Cloud.
- Impostare restrizioni della chiave e limiti di utilizzo/budget nel pannello Google Cloud.
- Dal pannello admin inserire ritiro e consegna e premere "Calcola percorso e prezzo indicativo".
- G.M. può impostare €/km, quota base e prezzo minimo. Il preventivo è calcolato come `max(prezzo_minimo, quota_base + km × €/km)`.
- Il risultato è indicativo; G.M. conferma e modifica il prezzo finale. Non viene addebitato alcun importo automaticamente.
- La chiave Google Maps resta lato server e non va inserita nel browser o condivisa in chat.

## Versione 13 – documenti e scadenze trasportatori
- Caricamento documenti PDF/JPG/PNG con limite dimensione configurabile.
- Metadati: tipo documento, data rilascio e scadenza.
- Verifica amministrativa: da verificare, approvato, respinto.
- Visualizzazione del file protetta dalla chiave amministratore.
- Endpoint di idoneità che segnala documenti in attesa o scaduti.

### Attenzione sicurezza
Il modulo è una base da collaudare: usare HTTPS, cartella documenti privata fuori dalla directory pubblica, backup cifrati, antivirus/scansione file, controllo accessi per utente e registrazione audit. Il controllo MIME è preliminare e non sostituisce l'analisi del contenuto. Non sono stati definiti automaticamente i documenti legalmente obbligatori per ogni tipo di trasporto: G.M. deve stabilire la checklist con il consulente. L'endpoint di idoneità non blocca ancora l'assegnazione: prima della produzione va collegato all'endpoint di assegnazione e alla checklist obbligatoria. 


## Versione 14 – verbali digitali
- Nel pannello amministratore, inserire l'ID della richiesta e selezionare RITIRO o CONSEGNA.
- Registrare luogo, chilometraggio, condizioni, danni e note.
- Allegare fino a 10 foto JPG/PNG e le immagini delle firme del trasportatore e del cliente/destinatario.
- Visualizzare i verbali della richiesta e generare un PDF con fotografie e firme.
- I file sono conservati nella cartella privata `REPORTS_DIR`, fuori dalla cartella pubblica.

### Limiti importanti prima dell'uso reale
Questa versione è un prototipo installabile, non è stata pubblicata su un server né installata sul telefono. I verbali e i caricamenti sono accessibili tramite la chiave amministratore: non esiste ancora un login personale per trasportatori/clienti. Le firme sono immagini caricate, non firme elettroniche qualificate; non si dichiara automaticamente la loro validità legale. Prima della produzione servono HTTPS, autenticazione per ruolo, scansione antivirus, limiti e controlli sul contenuto dei file, backup cifrati, informativa privacy e verifica legale del flusso di firma.

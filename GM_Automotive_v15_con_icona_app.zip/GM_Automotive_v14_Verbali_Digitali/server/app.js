require("dotenv").config();
const express=require("express"),fs=require("fs"),path=require("path"),crypto=require("crypto");
const Database=require("better-sqlite3");
const app=express();
const dbFile=process.env.DATABASE_FILE||"./data/gm-automotive.sqlite";
fs.mkdirSync(path.dirname(path.resolve(dbFile)),{recursive:true});
const db=new Database(dbFile);db.pragma("journal_mode=WAL");db.exec(fs.readFileSync(path.join(__dirname,"../database/schema.sql"),"utf8"));
app.use(express.json({limit:"1mb"}));app.use(express.static(path.join(__dirname,"../public")));
const same=(a,b)=>{const x=Buffer.from(String(a||"")),y=Buffer.from(String(b||""));return x.length===y.length&&crypto.timingSafeEqual(x,y)};
function admin(req,res,next){if(!process.env.ADMIN_API_KEY||!same(req.get("x-gm-admin-key"),process.env.ADMIN_API_KEY))return res.status(401).json({error:"Accesso non autorizzato"});next()}
function upsertCustomer(phone,name=""){
 const existing=db.prepare("SELECT id FROM customers WHERE phone=?").get(phone);
 if(existing){if(name)db.prepare("UPDATE customers SET name=? WHERE id=? AND (name='' OR name IS NULL)").run(name,existing.id);return existing.id}
 return db.prepare("INSERT INTO customers(name,phone) VALUES(?,?)").run(name,phone).lastInsertRowid;
}
app.get("/api/health",(req,res)=>res.json({ok:true,version:"14.0"}));
app.get("/api/requests",admin,(req,res)=>res.json(db.prepare(`SELECT r.*,c.name customer_name,c.phone customer_phone,t.name transporter_name
 FROM transport_requests r LEFT JOIN customers c ON c.id=r.customer_id LEFT JOIN transporters t ON t.id=r.transporter_id
 ORDER BY r.id DESC LIMIT 500`).all()));
app.post("/api/requests",admin,(req,res)=>{
 const b=req.body||{};if(!String(b.pickup||"").trim()||!String(b.delivery||"").trim())return res.status(400).json({error:"Ritiro e consegna sono obbligatori"});
 const tx=db.transaction(()=>{
 let cid=null;if(String(b.customer_phone||"").trim())cid=upsertCustomer(String(b.customer_phone).trim(),String(b.customer_name||"").trim());
 return db.prepare(`INSERT INTO transport_requests(customer_id,source,pickup,delivery,vehicle,plate,requested_date,notes)
 VALUES(?,?,?,?,?,?,?,?)`).run(cid,"MANUALE",b.pickup,b.delivery,b.vehicle||"",b.plate||"",b.requested_date||"",b.notes||"").lastInsertRowid;
 });
 res.status(201).json({id:tx(),message:"Richiesta inserita nell'archivio centrale"});
});
app.patch("/api/requests/:id/status",admin,(req,res)=>{
 const allowed=["DA_VERIFICARE","CONFERMATA","IN_ASSEGNAZIONE","IN_CORSO","CONSEGNATA","ANNULLATA"];
 if(!allowed.includes(req.body.status))return res.status(400).json({error:"Stato non valido"});
 const r=db.prepare("UPDATE transport_requests SET status=? WHERE id=?").run(req.body.status,req.params.id);res.json({updated:r.changes});
});
app.get("/api/transporters",admin,(req,res)=>res.json(db.prepare("SELECT * FROM transporters ORDER BY name").all()));
app.post("/api/transporters",admin,(req,res)=>{
 if(!String(req.body.name||"").trim())return res.status(400).json({error:"Nome obbligatorio"});
 const r=db.prepare("INSERT INTO transporters(name,phone,approval_status) VALUES(?,?,?)").run(req.body.name,req.body.phone||"","IN_ATTESA");res.status(201).json({id:r.lastInsertRowid});
});
app.patch("/api/transporters/:id/approval",admin,(req,res)=>{
 if(!["APPROVATO","IN_ATTESA","SOSPESO"].includes(req.body.approval_status))return res.status(400).json({error:"Stato non valido"});
 const r=db.prepare("UPDATE transporters SET approval_status=? WHERE id=?").run(req.body.approval_status,req.params.id);res.json({updated:r.changes});
});
app.post("/api/requests/:id/assign",admin,(req,res)=>{
 const t=db.prepare("SELECT id FROM transporters WHERE id=? AND approval_status='APPROVATO'").get(req.body.transporter_id);
 if(!t)return res.status(400).json({error:"Trasportatore non approvato"});
 const r=db.prepare("UPDATE transport_requests SET transporter_id=?,status='IN_ASSEGNAZIONE' WHERE id=?").run(t.id,req.params.id);res.json({updated:r.changes,assigned_by:"G.M."});
});
// Verify GET challenge from Meta.
app.get("/webhooks/whatsapp",(req,res)=>{
 if(req.query["hub.mode"]==="subscribe"&&same(req.query["hub.verify_token"],process.env.WHATSAPP_VERIFY_TOKEN))return res.status(200).send(String(req.query["hub.challenge"]||""));
 res.sendStatus(403);
});
// Raw body is needed to validate Meta signature.
app.post("/webhooks/whatsapp",express.raw({type:"application/json"}),(req,res)=>{
 const secret=process.env.WHATSAPP_APP_SECRET,signature=req.get("x-hub-signature-256")||"";
 if(!secret)return res.sendStatus(503);
 const expected="sha256="+crypto.createHmac("sha256",secret).update(req.body).digest("hex");
 if(!same(signature,expected))return res.sendStatus(401);
 let payload;try{payload=JSON.parse(req.body.toString("utf8"))}catch{return res.sendStatus(400)}
 const batch=[];
 for(const entry of payload.entry||[])for(const change of entry.changes||[])for(const m of change.value?.messages||[]){
  const text=m.text?.body||m.button?.text||m.interactive?.button_reply?.title||m.interactive?.list_reply?.title||"";
  if(m.id&&m.from)batch.push({id:m.id,from:m.from,type:m.type||"unknown",text,raw:m});
 }
 const save=db.transaction(items=>{
  for(const m of items){
   const added=db.prepare("INSERT OR IGNORE INTO whatsapp_messages(wamid,sender,message_type,message_text,raw_json) VALUES(?,?,?,?,?)").run(m.id,m.from,m.type,m.text,JSON.stringify(m.raw));
   if(!added.changes)continue;
   const cid=upsertCustomer(m.from,"");
   // Unstructured inbound messages are stored as requests to review; G.M. completes pickup/delivery before confirmation.
   db.prepare(`INSERT OR IGNORE INTO transport_requests(customer_id,source,notes,status,whatsapp_message_id)
   VALUES(?,'WHATSAPP',?,'DA_VERIFICARE',?)`).run(cid,m.text||("[Messaggio "+m.type+" senza testo]"),m.id);
  }
 });
 save(batch);res.sendStatus(200);
});

// Configurazione tariffaria gestita esclusivamente da G.M.
app.get("/api/pricing/settings",admin,(req,res)=>{
 const row=db.prepare("SELECT eur_per_km,base_fee,min_price,updated_at FROM pricing_settings WHERE id=1").get();
 res.json(row);
});
app.put("/api/pricing/settings",admin,(req,res)=>{
 const b=req.body||{};
 const rate=Number(b.eur_per_km),baseFee=Number(b.base_fee),minimum=Number(b.min_price);
 if(!Number.isFinite(rate)||rate<0||!Number.isFinite(baseFee)||baseFee<0||!Number.isFinite(minimum)||minimum<0)
   return res.status(400).json({error:"Inserire tariffe numeriche non negative"});
 db.prepare(`UPDATE pricing_settings SET eur_per_km=?,base_fee=?,min_price=?,updated_at=datetime('now') WHERE id=1`)
   .run(rate,baseFee,minimum);
 res.json(db.prepare("SELECT eur_per_km,base_fee,min_price,updated_at FROM pricing_settings WHERE id=1").get());
});
// Calcolo percorso stradale con Google Routes API. La chiave resta solo sul server.
app.post("/api/pricing/quote",admin,async(req,res)=>{
 const origin=String(req.body.origin||"").trim(),destination=String(req.body.destination||"").trim();
 if(!origin||!destination)return res.status(400).json({error:"Inserire indirizzo di ritiro e consegna"});
 const apiKey=process.env.GOOGLE_MAPS_API_KEY;
 if(!apiKey)return res.status(503).json({error:"Calcolo percorso non configurato: manca GOOGLE_MAPS_API_KEY sul server"});
 try{
  const response=await fetch("https://routes.googleapis.com/directions/v2:computeRoutes",{
   method:"POST",
   headers:{"Content-Type":"application/json","X-Goog-Api-Key":apiKey,"X-Goog-FieldMask":"routes.distanceMeters,routes.duration"},
   body:JSON.stringify({
    origin:{address:origin},destination:{address:destination},
    travelMode:"DRIVE",routingPreference:"TRAFFIC_UNAWARE",computeAlternativeRoutes:false,
    languageCode:"it",units:"METRIC"
   })
  });
  const data=await response.json();
  if(!response.ok)return res.status(502).json({error:"Servizio mappe non disponibile",details:data.error?.message||"Errore API"});
  const route=data.routes?.[0];
  if(!route||!Number.isFinite(route.distanceMeters))return res.status(404).json({error:"Percorso stradale non trovato"});
  const km=route.distanceMeters/1000;
  const settings=db.prepare("SELECT eur_per_km,base_fee,min_price FROM pricing_settings WHERE id=1").get();
  const calculated= Math.max(settings.min_price,settings.base_fee+km*settings.eur_per_km);
  res.json({
   origin,destination,distance_km:Math.round(km*10)/10,
   duration:route.duration||null,eur_per_km:settings.eur_per_km,
   base_fee:settings.base_fee,min_price:settings.min_price,
   suggested_price_eur:Math.round(calculated*100)/100,
   editable_by_gm:true,
   note:"Preventivo indicativo: G.M. verifica il percorso e decide il prezzo finale."
  });
 }catch(e){res.status(502).json({error:"Errore nel calcolo del percorso"});}
});


// Documenti trasportatori: file privati, non serviti dalla cartella pubblica.
const multer=require("multer");
const docsDir=path.resolve(process.env.DOCUMENTS_DIR||"./private-documents");
fs.mkdirSync(docsDir,{recursive:true});
const maxMb=Math.max(1,Math.min(20,Number(process.env.MAX_DOCUMENT_MB||10)));
const allowedMime=new Set(["application/pdf","image/jpeg","image/png"]);
const upload=multer({
 storage:multer.diskStorage({
  destination:(req,file,cb)=>cb(null,docsDir),
  filename:(req,file,cb)=>cb(null,crypto.randomUUID()+path.extname(file.originalname).toLowerCase())
 }),
 limits:{fileSize:maxMb*1024*1024,files:1},
 fileFilter:(req,file,cb)=>cb(null,allowedMime.has(file.mimetype))
});
app.get("/api/admin/transporter-documents",admin,(req,res)=>{
 const rows=db.prepare(`SELECT d.id,d.transporter_id,t.name transporter_name,d.document_type,
 d.original_name,d.issue_date,d.expiry_date,d.review_status,d.review_notes,d.uploaded_at
 FROM transporter_documents d JOIN transporters t ON t.id=d.transporter_id
 ORDER BY d.uploaded_at DESC`).all();
 res.json(rows);
});
app.post("/api/admin/transporters/:id/documents",admin,(req,res)=>{
 upload.single("document")(req,res,err=>{
  if(err)return res.status(400).json({error:err.code==="LIMIT_FILE_SIZE"?"File troppo grande":err.message||"Caricamento non riuscito"});
  if(!req.file)return res.status(400).json({error:"Caricare un PDF, JPG o PNG"});
  const t=db.prepare("SELECT id FROM transporters WHERE id=?").get(req.params.id);
  if(!t){fs.unlinkSync(req.file.path);return res.status(404).json({error:"Trasportatore non trovato"});}
  const {document_type,issue_date,expiry_date}=req.body;
  if(!String(document_type||"").trim()){fs.unlinkSync(req.file.path);return res.status(400).json({error:"Tipo documento obbligatorio"});}
  const result=db.prepare(`INSERT INTO transporter_documents
  (transporter_id,document_type,original_name,stored_name,mime_type,file_size,issue_date,expiry_date)
  VALUES(?,?,?,?,?,?,?,?)`).run(t.id,String(document_type),req.file.originalname,req.file.filename,req.file.mimetype,req.file.size,issue_date||null,expiry_date||null);
  res.status(201).json({id:result.lastInsertRowid,review_status:"DA_VERIFICARE"});
 });
});
app.patch("/api/admin/transporter-documents/:id/review",admin,(req,res)=>{
 const status=req.body.review_status;
 if(!["APPROVATO","RESPINTO","DA_VERIFICARE"].includes(status))return res.status(400).json({error:"Esito non valido"});
 const result=db.prepare(`UPDATE transporter_documents SET review_status=?,review_notes=?,reviewed_at=datetime('now') WHERE id=?`)
 .run(status,String(req.body.review_notes||""),req.params.id);
 res.json({updated:result.changes});
});
app.get("/api/admin/transporter-documents/:id/file",admin,(req,res)=>{
 const doc=db.prepare("SELECT * FROM transporter_documents WHERE id=?").get(req.params.id);
 if(!doc)return res.sendStatus(404);
 const file=path.join(docsDir,doc.stored_name);
 if(!fs.existsSync(file))return res.sendStatus(404);
 res.type(doc.mime_type).sendFile(file);
});
// Stato di idoneità documentale: verifica scadenze, ma l'approvazione operativa resta decisione G.M.
app.get("/api/admin/transporters/:id/eligibility",admin,(req,res)=>{
 const docs=db.prepare("SELECT document_type,expiry_date,review_status FROM transporter_documents WHERE transporter_id=?").all(req.params.id);
 const today=new Date().toISOString().slice(0,10);
 const expired=docs.filter(d=>d.expiry_date&&d.expiry_date<today);
 const pending=docs.filter(d=>d.review_status!=="APPROVATO");
 res.json({transporter_id:Number(req.params.id),documents_count:docs.length,expired,pending,eligible_for_assignment:docs.length>0&&expired.length===0&&pending.length===0});
});


// Verbali digitali di ritiro/consegna. File privati e accessibili solo a G.M. in questa versione.
const PDFDocument=require("pdfkit");
const reportsDir=path.resolve(process.env.REPORTS_DIR||"./private-reports");
fs.mkdirSync(reportsDir,{recursive:true});
const reportUpload=multer({
 storage:multer.diskStorage({destination:(req,file,cb)=>cb(null,reportsDir),filename:(req,file,cb)=>cb(null,crypto.randomUUID()+path.extname(file.originalname).toLowerCase())}),
 limits:{fileSize:15*1024*1024,files:12},
 fileFilter:(req,file,cb)=>cb(null,["image/jpeg","image/png"].includes(file.mimetype))
});
app.get("/api/admin/requests/:id/reports",admin,(req,res)=>{
 const rows=db.prepare("SELECT * FROM transport_reports WHERE request_id=? ORDER BY occurred_at DESC,id DESC").all(req.params.id);
 const files=db.prepare("SELECT id,report_id,file_kind,original_name,mime_type,file_size,uploaded_at FROM report_files WHERE report_id IN (SELECT id FROM transport_reports WHERE request_id=?) ORDER BY id").all(req.params.id);
 res.json(rows.map(r=>({...r,files:files.filter(f=>f.report_id===r.id)})));
});
app.post("/api/admin/requests/:id/reports",admin,(req,res)=>{
 reportUpload.fields([{name:"photos",maxCount:10},{name:"transporter_signature",maxCount:1},{name:"customer_signature",maxCount:1}])(req,res,err=>{
  if(err)return res.status(400).json({error:err.code==="LIMIT_FILE_SIZE"?"Ogni file deve essere massimo 15 MB":err.message||"Caricamento non riuscito"});
  const files=Object.entries(req.files||{}).flatMap(([field,arr])=>arr.map(f=>({...f,kind:field==="photos"?"FOTO":field==="transporter_signature"?"FIRMA_TRASPORTATORE":"FIRMA_CLIENTE"})));
  const cleanup=()=>files.forEach(f=>{try{fs.unlinkSync(f.path)}catch{}});
  const request=db.prepare("SELECT id FROM transport_requests WHERE id=?").get(req.params.id);
  if(!request){cleanup();return res.status(404).json({error:"Richiesta di trasporto non trovata"});}
  const b=req.body||{},kind=String(b.report_type||"").toUpperCase();
  if(!["RITIRO","CONSEGNA"].includes(kind)){cleanup();return res.status(400).json({error:"Tipo verbale non valido: scegliere RITIRO o CONSEGNA"});}
  const mileage=b.mileage===""||b.mileage==null?null:Number(b.mileage);
  if(mileage!==null&&(!Number.isInteger(mileage)||mileage<0)){cleanup();return res.status(400).json({error:"Chilometraggio non valido"});}
  try{
   const tx=db.transaction(()=>{
    const r=db.prepare(`INSERT INTO transport_reports(request_id,report_type,location,mileage,vehicle_condition,damage_notes,transporter_notes)
    VALUES(?,?,?,?,?,?,?)`).run(req.params.id,kind,String(b.location||""),mileage,String(b.vehicle_condition||""),String(b.damage_notes||""),String(b.transporter_notes||""));
    const add=db.prepare("INSERT INTO report_files(report_id,file_kind,original_name,stored_name,mime_type,file_size) VALUES(?,?,?,?,?,?)");
    files.forEach(f=>add.run(r.lastInsertRowid,f.kind,f.originalname,f.filename,f.mimetype,f.size));
    return r.lastInsertRowid;
   });
   const id=tx();res.status(201).json({id,report_type:kind,message:"Verbale registrato"});
  }catch(e){cleanup();res.status(500).json({error:"Impossibile salvare il verbale"});}
 });
});
app.get("/api/admin/report-files/:id",admin,(req,res)=>{
 const f=db.prepare("SELECT * FROM report_files WHERE id=?").get(req.params.id);if(!f)return res.sendStatus(404);
 const file=path.join(reportsDir,f.stored_name);if(!fs.existsSync(file))return res.sendStatus(404);
 res.setHeader("Content-Disposition",`inline; filename="${encodeURIComponent(f.original_name)}"`);res.type(f.mime_type).sendFile(file);
});
app.get("/api/admin/reports/:id/pdf",admin,(req,res)=>{
 const r=db.prepare(`SELECT p.*,q.vehicle,q.plate,q.pickup,q.delivery,q.id request_number FROM transport_reports p JOIN transport_requests q ON q.id=p.request_id WHERE p.id=?`).get(req.params.id);
 if(!r)return res.sendStatus(404);
 const files=db.prepare("SELECT * FROM report_files WHERE report_id=? ORDER BY id").all(r.id);
 res.setHeader("Content-Type","application/pdf");res.setHeader("Content-Disposition",`attachment; filename=verbale-GM-${r.id}.pdf`);
 const doc=new PDFDocument({size:"A4",margin:48,info:{Title:`Verbale ${r.report_type} G.M. Automotive`,Author:"G.M. Automotive"}});doc.pipe(res);
 const gold="#B8954A";
 doc.fillColor(gold).fontSize(20).text("G.M. AUTOMOTIVE",{align:"center"});doc.moveDown(.3);
 doc.fillColor("#222").fontSize(16).text(`VERBALE DI ${r.report_type}`,{align:"center"});doc.moveDown();
 doc.fontSize(10).fillColor("#333").text(`Numero verbale: ${r.id}    Richiesta: ${r.request_number}`);
 doc.text(`Data e ora: ${r.occurred_at}`);doc.text(`Luogo: ${r.location||"Non indicato"}`);doc.moveDown();
 doc.fontSize(12).fillColor(gold).text("DATI DEL VEICOLO");doc.fillColor("#222").fontSize(10);
 doc.text(`Veicolo: ${r.vehicle||"Non indicato"}`);doc.text(`Targa: ${r.plate||"Non indicata"}`);doc.text(`Percorso: ${r.pickup||"—"} → ${r.delivery||"—"}`);doc.text(`Chilometraggio: ${r.mileage==null?"Non indicato":r.mileage+" km"}`);doc.moveDown();
 doc.fontSize(12).fillColor(gold).text("CONDIZIONI E NOTE");doc.fillColor("#222").fontSize(10);
 doc.text(`Condizioni del veicolo: ${r.vehicle_condition||"Non indicate"}`);doc.moveDown(.3);doc.text(`Danni/anomalie: ${r.damage_notes||"Nessuna nota inserita"}`);doc.moveDown(.3);doc.text(`Note trasportatore: ${r.transporter_notes||"—"}`);doc.moveDown();
 for(const [kind,label] of [["FIRMA_TRASPORTATORE","Firma trasportatore"],["FIRMA_CLIENTE","Firma cliente/destinatario"]]){
  const f=files.find(x=>x.file_kind===kind);doc.fillColor(gold).fontSize(11).text(label);doc.fillColor("#222");
  if(f&&/^image\/(jpeg|png)$/.test(f.mime_type)&&fs.existsSync(path.join(reportsDir,f.stored_name))){try{doc.image(path.join(reportsDir,f.stored_name),{fit:[190,65]})}catch{doc.fontSize(9).text("Immagine firma non leggibile")}}
  else doc.fontSize(9).text("Firma non caricata");doc.moveDown(.5);
 }
 const photos=files.filter(f=>f.file_kind==="FOTO"&&/^image\/(jpeg|png)$/.test(f.mime_type));
 if(photos.length){doc.addPage();doc.fillColor(gold).fontSize(14).text("FOTOGRAFIE ALLEGATE");doc.moveDown();for(const f of photos){const fp=path.join(reportsDir,f.stored_name);if(fs.existsSync(fp)){try{doc.image(fp,{fit:[230,150],align:"center"});doc.moveDown(.5);doc.fillColor("#333").fontSize(8).text(f.original_name);doc.moveDown()}catch{}}}}
 doc.moveDown();doc.fillColor("#777").fontSize(8).text("Documento generato dal gestionale. Le immagini delle firme sono una registrazione grafica: la loro validità giuridica e l'eventuale valore probatorio devono essere verificati con un professionista.",{align:"left"});doc.end();
});


app.listen(Number(process.env.PORT||3000),()=>console.log("G.M. Automotive v11 avviato"));

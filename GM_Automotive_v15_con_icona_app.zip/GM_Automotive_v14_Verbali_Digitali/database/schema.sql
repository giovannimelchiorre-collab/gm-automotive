PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS customers(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL DEFAULT '',
 phone TEXT NOT NULL UNIQUE,
 created_at TEXT NOT NULL DEFAULT(datetime('now'))
);
CREATE TABLE IF NOT EXISTS transporters(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 phone TEXT DEFAULT '',
 approval_status TEXT NOT NULL DEFAULT 'IN_ATTESA'
);
CREATE TABLE IF NOT EXISTS transport_requests(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 customer_id INTEGER,
 source TEXT NOT NULL DEFAULT 'MANUALE',
 pickup TEXT NOT NULL DEFAULT '',
 delivery TEXT NOT NULL DEFAULT '',
 vehicle TEXT NOT NULL DEFAULT '',
 plate TEXT DEFAULT '',
 requested_date TEXT DEFAULT '',
 notes TEXT DEFAULT '',
 status TEXT NOT NULL DEFAULT 'DA_VERIFICARE',
 transporter_id INTEGER,
 whatsapp_message_id TEXT UNIQUE,
 created_at TEXT NOT NULL DEFAULT(datetime('now')),
 FOREIGN KEY(customer_id) REFERENCES customers(id),
 FOREIGN KEY(transporter_id) REFERENCES transporters(id)
);
CREATE TABLE IF NOT EXISTS whatsapp_messages(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 wamid TEXT NOT NULL UNIQUE,
 sender TEXT NOT NULL,
 message_type TEXT NOT NULL,
 message_text TEXT,
 received_at TEXT NOT NULL DEFAULT(datetime('now')),
 raw_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS pricing_settings(
 id INTEGER PRIMARY KEY CHECK(id=1),
 eur_per_km REAL NOT NULL DEFAULT 1.20,
 base_fee REAL NOT NULL DEFAULT 0,
 min_price REAL NOT NULL DEFAULT 0,
 updated_at TEXT NOT NULL DEFAULT(datetime('now'))
);
INSERT OR IGNORE INTO pricing_settings(id,eur_per_km,base_fee,min_price)
VALUES(1,1.20,0,0);

CREATE TABLE IF NOT EXISTS transporter_documents(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 transporter_id INTEGER NOT NULL,
 document_type TEXT NOT NULL,
 original_name TEXT NOT NULL,
 stored_name TEXT NOT NULL,
 mime_type TEXT NOT NULL,
 file_size INTEGER NOT NULL,
 issue_date TEXT,
 expiry_date TEXT,
 review_status TEXT NOT NULL DEFAULT 'DA_VERIFICARE',
 review_notes TEXT DEFAULT '',
 uploaded_at TEXT NOT NULL DEFAULT(datetime('now')),
 reviewed_at TEXT,
 FOREIGN KEY(transporter_id) REFERENCES transporters(id)
);


CREATE TABLE IF NOT EXISTS transport_reports(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 request_id INTEGER NOT NULL,
 report_type TEXT NOT NULL CHECK(report_type IN ('RITIRO','CONSEGNA')),
 occurred_at TEXT NOT NULL DEFAULT(datetime('now')),
 location TEXT DEFAULT '',
 mileage INTEGER,
 vehicle_condition TEXT NOT NULL DEFAULT '',
 damage_notes TEXT DEFAULT '',
 transporter_notes TEXT DEFAULT '',
 created_at TEXT NOT NULL DEFAULT(datetime('now')),
 FOREIGN KEY(request_id) REFERENCES transport_requests(id)
);
CREATE TABLE IF NOT EXISTS report_files(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 report_id INTEGER NOT NULL,
 file_kind TEXT NOT NULL CHECK(file_kind IN ('FOTO','FIRMA_TRASPORTATORE','FIRMA_CLIENTE')),
 original_name TEXT NOT NULL,
 stored_name TEXT NOT NULL,
 mime_type TEXT NOT NULL,
 file_size INTEGER NOT NULL,
 uploaded_at TEXT NOT NULL DEFAULT(datetime('now')),
 FOREIGN KEY(report_id) REFERENCES transport_reports(id) ON DELETE CASCADE
);
